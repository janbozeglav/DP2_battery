/****************************************************************
 * FILENAME:     PER_int.c
 * DESCRIPTION:  periodic interrupt code
 * AUTHOR:       Mitja Nemec
 * DATE:         16.1.2009
 *
 ****************************************************************/
#include    "PER_int.h"
#include    "TIC_toc.h"



// za izracunun napetostni
long napetost_raw = 0;
long napetost_offset = 0;
float napetost_gain = 0.00081;
float napetost = 0.0;

// za izracun toka
long tok_raw = 0;
long tok_offset = 2048;
float tok_gain = 0.000161;
float tok = 0.0;

// za oceno obremenjenosti CPU-ja
float   cpu_load  = 0.0;
long    interrupt_cycles = 0;

// spremenljikva s katero �tejemo kolikokrat se je prekinitev predolgo izvajala
int interrupt_overflow_counter = 0;


/**************************************************************
 * spremenljivke, ki jih potrebujemo meritev moci in kapacitete
 **************************************************************/
float naboj=0;
float nabojON=0;
float nabojOFF=0;
float energija=0;
float energijaON=0;
float energijaOFF=0;
float tok_offs=0;
float tok_raw_offs=0;

float nabojON1=0;
float nabojOFF1=0;
float nabojON2=0;
float nabojOFF2=0;

float energijaON1=0;
float energijaOFF1=0;
float energijaON2=0;
float energijaOFF2=0;

int ON=1;
unsigned long int i=0;
/**************************************************************
 * Prekinitev, ki v kateri se izvaja regulacija
 **************************************************************/
#pragma CODE_SECTION(PER_int, "ramfuncs");
void interrupt PER_int(void)
{
    /* lokalne spremenljivke */

    // najprej povem da sem se odzzval na prekinitev
    // Spustimo INT zastavico casovnika ePWM1
    EPwm1Regs.ETCLR.bit.INT = 1;
    // Spustimo INT zastavico v PIE enoti
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;

    // pozenem stoprico
    interrupt_cycles = TIC_time;
    TIC_start();

    // izracunam obremenjenost procesorja
    cpu_load = (float)interrupt_cycles / (CPU_FREQ/SWITCH_FREQ);

    // ce se polni potem izklopim breme
    if (PCB_charge_state() == TRUE)
    {
        PCB_load_off();
        if (ON==0)
        {
        ON=1;
        nabojON2=nabojON1;
        nabojON1=nabojON;
        naboj=0;
        nabojON=0;

        energijaON2=energijaON1;
        energijaON1=energijaON;
        energija=0;
        energijaON=0;


        }
        // pocakam da ADC konca s pretvorbo
        ADC_wait();

        // preracunam napetost
        napetost_raw = NAPETOST;
        napetost = napetost_raw * napetost_gain;

        tok_raw = TOK - tok_offset - tok_raw_offs;
        tok = tok_raw * tok_gain;

        /*******************************************************
        * Tukaj pride koda za meritev naboja in energije
        *******************************************************/
        naboj=tok*0.000025; /* Q=i*cas */
        energija=tok*napetost*0.000025; /*W=P*t=U*I*t  */

        nabojON=nabojON+naboj;
        energijaON=energijaON+energija;


    }

    else if (ON==1)

    {

        if(i==1200000) // imax=4294967296
        {
        // pocakam da ADC konca s pretvorbo
         ADC_wait();

         // preracunam napetost

         tok_raw_offs = TOK - tok_offset;
         tok_offs = -tok_raw_offs * tok_gain;

         ON=0;
         i=0;

         nabojOFF2=nabojOFF1;
         nabojOFF1=nabojOFF;
         naboj=0;
         nabojOFF=0;


         energijaOFF2=energijaOFF1;
         energijaOFF1=energijaOFF;
         energija=0;

         energijaOFF=0;

         PCB_load_on();

        }
        else
        i=i+1;

    }
    else
    {
        ///////////////////////////////

        // pocakam da ADC konca s pretvorbo
        ADC_wait();

        // preracunam napetost
        napetost_raw = NAPETOST;
        napetost = napetost_raw * napetost_gain;

        tok_raw = TOK - tok_offset - tok_raw_offs;
        tok = -tok_raw * tok_gain;

        /*******************************************************
        * Tukaj pride koda za meritev naboja in energije
        *******************************************************/
        naboj=tok*0.000025; /* Q=i*cas */
        energija=tok*napetost*0.000025; /*W=P*t=U*I*t  */

        nabojOFF=nabojOFF+naboj;
        energijaOFF=energijaOFF+energija;


///////////////////////////////

    }

    ////////////////////////////////////////////////////////////////////////////////////////////



    
    ////////////////////////////////////////////////
    
    /* preverim, �e me slu�ajno �aka nova prekinitev.
       �e je temu tako, potem je nekaj hudo narobe
       saj je �as izvajanja prekinitve predolg
       vse skupaj se mora zgoditi najmanj 10krat,
       da re�emo da je to res problem
     */
    if (EPwm1Regs.ETFLG.bit.INT == TRUE)
    {
        // povecam stevec, ki steje take dogodke
        interrupt_overflow_counter = interrupt_overflow_counter + 1;

        // in ce se je vse skupaj zgodilo 10 krat se ustavim
        // v kolikor uC krmili kak�en resen HW, potem mo�no
        // proporo�am lep�e "hendlanje" takega dogodka
        // beri:ugasni mo�nostno stopnjo, ...
        if (interrupt_overflow_counter >= 10)
        {
            asm(" ESTOP0");
        }
    }

    // stopam
    TIC_stop();

}   // end of PWM_int



/**************************************************************
 * Funckija, ki pripravi vse potrebno za izvajanje
 * prekinitvene rutine
 **************************************************************/
void PER_int_setup(void)
{

    // Pro�enje prekinitve 
    EPwm1Regs.ETSEL.bit.INTSEL = ET_CTR_ZERO;    //spro�i prekinitev na periodo
    EPwm1Regs.ETPS.bit.INTPRD = ET_1ST;         //ob vsakem prvem dogodku
    EPwm1Regs.ETCLR.bit.INT = 1;                //clear possible flag
    EPwm1Regs.ETSEL.bit.INTEN = 1;              //enable interrupt

    // registriram prekinitveno rutino
    EALLOW;
    PieVectTable.EPWM1_INT = &PER_int;
    EDIS;
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;
    PieCtrlRegs.PIEIER3.bit.INTx1 = 1;
    IER |= M_INT3;
    // da mi prekinitev te�e  tudi v real time na�inu
    // (za razhor��evanje main zanke in BACK_loop zanke)
    SetDBGIER(M_INT3);
}
